package com.example.project;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;

import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity7 extends AppCompatActivity
{
    Button b1,b2,x2,x3,x4,x5,x6;
    TextView a,b,c,a1,a2,c1,a3,a4,c4;

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        b = findViewById(R.id.next);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button15);
        x2 = findViewById(R.id.button2);
        x3 = findViewById(R.id.button3);
        a = findViewById(R.id.textView3);
        b = findViewById(R.id.textView4);
        c = findViewById(R.id.textView5);
        a1 = findViewById(R.id.textView11);
        a2 = findViewById(R.id.textView7);
        c1 = findViewById(R.id.textView8);
        a3 = findViewById(R.id.textView9);
        a4 = findViewById(R.id.textView10);
        c4 = findViewById(R.id.puran);

        db = openOrCreateDatabase("Customer", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS customer(a VARCHAR,b VARCHAR,c Integer);");

        b.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openSecondActivity();
            }

        });

        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (a.getText().toString().trim().length() == 0 ||
                        b.getText().toString().trim().length() == 0 ||
                        c.getText().toString().trim().length() == 0) {
                    showMessage("Failed", "Record NOT added successfully");
                    return;
                }
                db.execSQL("INSERT INTO customer VALUES('" + a.getText() + "','" + b.getText() +
                        "','" + c.getText() + "');");
                showMessage("Success", "Record added successfully");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c = db.rawQuery("SELECT * FROM customer", null);
                if (c.getCount() == 0) {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (c.moveToNext()) {
                    buffer.append("Food item: " + c.getString(0) + "\n");
                    buffer.append("Restaurant: " + c.getString(1) + "\n");
                    buffer.append("Price: " + c.getString(2) + "\n\n");
                }
                showMessage("Order Details", buffer.toString());
            }
        });

        x2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (a1.getText().toString().trim().length() == 0 ||
                        a2.getText().toString().trim().length() == 0 ||
                        c1.getText().toString().trim().length() == 0) {
                    showMessage("Failed", "Record NOT added successfully");
                    return;
                }
                db.execSQL("INSERT INTO customer VALUES('" + a1.getText() + "','" + a2.getText() +
                        "','" + c1.getText() + "');");
                showMessage("Success", "Record added successfully");
            }
        });

        x3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (a3.getText().toString().trim().length() == 0 ||
                        a4.getText().toString().trim().length() == 0 ||
                        c4.getText().toString().trim().length() == 0) {
                    showMessage("Failed", "Record NOT added successfully");
                    return;
                }
                db.execSQL("INSERT INTO customer VALUES('" + a3.getText() + "','" + a4.getText() +
                        "','" + c4.getText() + "');");
                showMessage("Success", "Record added successfully");
            }
        });
    }
    public void showMessage (String title, String message)
    {
        Builder builder = new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(" Pay", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {

            db.execSQL("drop table  if exists customer");
            Intent pay = new Intent(MainActivity7.this, Pyment.class);
                startActivity(pay);
        }

    });
        builder.show();
    }


    public void openSecondActivity()
    {
        Intent i = new Intent(MainActivity7.this, MainActivity8.class);
        startActivity(i);
    }
}
