package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class MainActivity13 extends AppCompatActivity
{
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main13);

        b = findViewById(R.id.next);
        b.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v)
            {
                openSecondActivity();
            }
        });
    }
    public void openSecondActivity()
    {
        Intent i = new Intent(MainActivity13.this,MainActivity14.class);
        startActivity(i);
    }
}