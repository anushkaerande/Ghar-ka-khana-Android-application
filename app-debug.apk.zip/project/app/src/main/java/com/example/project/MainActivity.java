package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    Button button,button2,button3,button4;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                openSecondActivity();

            }

        });
        button2=findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                openThirdActivity();

            }


    });

    }
    public void openSecondActivity()
    {
        Intent i = new Intent(MainActivity.this,MainActivity2.class);
        startActivity(i);
    }
    public void openThirdActivity()
    {
        Intent i = new Intent(MainActivity.this,MainActivity3.class);
        startActivity(i);
    }


}