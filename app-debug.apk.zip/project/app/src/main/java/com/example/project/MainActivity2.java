package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity
{
    Button b,b1,b2,b3;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        b1 = findViewById(R.id.button8);
        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override

            public void onClick(View v)
            {
                openThird();
            }
        });
        b2 = findViewById(R.id.button6);
        b2.setOnClickListener(new View.OnClickListener()
        {
            @Override

            public void onClick(View v)
            {
                openForth();
            }
        });
        b3 = findViewById(R.id.button5);
        b3.setOnClickListener(new View.OnClickListener()
        {
            @Override

            public void onClick(View v)
            {
                openFifth();
            }
        });

    }

    public void openThird()
    {
        Intent i = new Intent(MainActivity2.this,MainActivity7.class);
        startActivity(i);
    }
    public void openForth()
    {
        Intent i = new Intent(MainActivity2.this,MainActivity10.class);
        startActivity(i);
    }
    public void openFifth()
    {
        Intent i = new Intent(MainActivity2.this,MainActivity11.class);
        startActivity(i);
    }
}