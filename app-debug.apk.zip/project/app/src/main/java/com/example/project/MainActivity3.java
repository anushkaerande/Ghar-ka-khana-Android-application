package com.example.project;



import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity3 extends AppCompatActivity {
    Button b, b1, b2, b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        b = findViewById(R.id.button5);
        b.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openFifth();
            }
        });
        b1 = findViewById(R.id.button6);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openThird();
            }
        });
        b2 = findViewById(R.id.button8);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openForth();
            }
        });


    }


    public void openThird() {
        Intent i = new Intent(MainActivity3.this, MainActivity12.class);
        startActivity(i);
    }

    public void openForth() {
        Intent i = new Intent(MainActivity3.this, MainActivity13.class);
        startActivity(i);
    }

    public void openFifth() {
        Intent i = new Intent(MainActivity3.this, MainActivity15.class);
        startActivity(i);
    }
}